
export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'Noto Serif CJK JP' }}>
      <h1>어서 와! 🐠 수조 데스크탑에 오신 걸 환영해요.</h1>
      <p>이건 기본 인덱스 페이지예요. 지금부터 마음껏 꾸며봐요!</p>
    </div>
  )
}
